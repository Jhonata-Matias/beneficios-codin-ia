import { copyFile } from 'fs/promises';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function copyWorker() {
  try {
    const source = join(__dirname, '../node_modules/pdfjs-dist/build/pdf.worker.min.js');
    const dest = join(__dirname, '../public/pdf.worker.min.js');
    await copyFile(source, dest);
    console.log('PDF.js worker copied successfully');
  } catch (error) {
    console.error('Error copying PDF.js worker:', error);
    process.exit(1);
  }
}

copyWorker();