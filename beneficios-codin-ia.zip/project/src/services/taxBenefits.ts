import axios from 'axios';
import { parseISO, isBefore } from 'date-fns';
import { TaxBenefit, BenefitType } from '../types/taxBenefits';

const SERPER_API_KEY = '430744e4d615f1be9fbe0fbf635328de631d9c18';

interface SearchResponse {
  organic: Array<{
    title: string;
    link: string;
    snippet: string;
  }>;
}

interface ParsedBenefit {
  name: string;
  legislation: {
    reference: string;
    url?: string;
  };
  type: BenefitType[];
  deadline: string;
  details?: string;
  status: 'active' | 'expired';
}

export async function searchTaxBenefits(mainActivity: string): Promise<SearchResponse> {
  if (!mainActivity) {
    throw new Error('Atividade principal não fornecida');
  }

  // Remove CNAE code if present
  const activityDescription = mainActivity.split('-').slice(1).join('-').trim();

  try {
    const response = await axios.post('https://google.serper.dev/search', {
      q: `benefícios fiscais RJ para ${activityDescription}`,
      gl: 'br',
      hl: 'pt-br',
      num: 10
    }, {
      headers: {
        'X-API-KEY': SERPER_API_KEY,
        'Content-Type': 'application/json',
      },
    });

    return response.data;
  } catch (error) {
    console.error('Erro na busca de benefícios:', error);
    if (axios.isAxiosError(error)) {
      throw new Error(`Erro na busca de benefícios: ${error.response?.data?.message || error.message}`);
    }
    throw error;
  }
}

export async function parseTaxBenefits(searchResults: SearchResponse): Promise<ParsedBenefit[]> {
  try {
    const response = await axios.get('https://legislacao.fazenda.rj.gov.br/wcc/?web_id=WCC262789');
    const text = response.data;
    
    // Parse HTML content without using DOMParser
    const benefits: ParsedBenefit[] = [];
    const sections = text.split('<p>&nbsp;</p>');
    
    sections.forEach(section => {
      const nameMatch = section.match(/<strong>(.*?)<\/strong>/);
      if (!nameMatch) return;

      const name = nameMatch[1].replace(/\.$/, '').trim();
      
      const typeMatch = section.match(/(?:Diferimento|Isenção|Redução[^<]*|Crédito Presumido|Tributação sobre saída)/);
      const types = typeMatch 
        ? [typeMatch[0] as BenefitType]
        : [];

      const deadlineMatch = section.match(/Prazo até ([^<\.]*)/);
      const deadline = deadlineMatch ? deadlineMatch[1].trim() : 'Prazo indeterminado';

      const legislationMatch = section.match(/<a href="([^"]*)"[^>]*>([^<]*)<\/a>/);
      const legislation = legislationMatch ? {
        reference: legislationMatch[2].trim(),
        url: legislationMatch[1].startsWith('http') 
          ? legislationMatch[1] 
          : `https://legislacao.fazenda.rj.gov.br${legislationMatch[1]}`
      } : {
        reference: 'Não especificada',
        url: undefined
      };

      const detailsMatches = section.match(/<p[^>]*>(?!Prazo)([^<]+)<\/p>/g);
      const details = detailsMatches 
        ? detailsMatches
            .map(match => match.replace(/<[^>]+>/g, '').trim())
            .filter(detail => detail && !detail.includes('Prazo'))
            .join('\n')
        : undefined;

      benefits.push({
        name,
        legislation,
        type: types,
        deadline,
        details,
        status: 'active'
      });
    });

    return benefits;
  } catch (error) {
    console.error('Erro ao processar benefícios:', error);
    throw new Error('Falha ao processar os benefícios fiscais');
  }
}

export function filterEligibleBenefits(
  benefits: ParsedBenefit[],
  revenue: number,
  activity: string
): ParsedBenefit[] {
  const currentDate = new Date();
  const normalizedActivity = activity.toLowerCase().split('-').slice(1).join('-').trim();
  
  return benefits.filter(benefit => {
    // Check deadline
    if (benefit.deadline && benefit.deadline !== 'Prazo indeterminado') {
      try {
        const deadlineDate = parseISO(benefit.deadline);
        if (isBefore(deadlineDate, currentDate)) {
          return false;
        }
      } catch (error) {
        console.warn(`Data inválida para o benefício ${benefit.name}: ${benefit.deadline}`);
      }
    }

    // Check revenue restrictions
    if (revenue > 4800000 && benefit.details?.toLowerCase().includes('simples nacional')) {
      return false;
    }

    // Check activity relevance
    const normalizedBenefitName = benefit.name.toLowerCase();
    const normalizedDetails = benefit.details?.toLowerCase() || '';

    const activityKeywords = normalizedActivity.split(' ');
    return activityKeywords.some(keyword => 
      normalizedBenefitName.includes(keyword) || normalizedDetails.includes(keyword)
    );
  });
}

export function enrichBenefitDetails(benefit: ParsedBenefit): ParsedBenefit {
  const enrichedBenefit = { ...benefit };

  enrichedBenefit.type.forEach(type => {
    const details = benefit.details?.toLowerCase() || '';
    
    switch (type) {
      case 'Redução de Base de Cálculo': {
        const match = details.match(/redução de (\d+)%/);
        if (match) {
          enrichedBenefit.details = `Percentual de redução: ${match[1]}%\n${enrichedBenefit.details || ''}`;
        }
        break;
      }
      case 'Diferimento': {
        const match = details.match(/diferido por (\d+)/);
        if (match) {
          enrichedBenefit.details = `Período de diferimento: ${match[1]} dias\n${enrichedBenefit.details || ''}`;
        }
        break;
      }
      case 'Crédito Presumido': {
        const match = details.match(/crédito de (\d+)%/);
        if (match) {
          enrichedBenefit.details = `Percentual do crédito: ${match[1]}%\n${enrichedBenefit.details || ''}`;
        }
        break;
      }
    }
  });

  return enrichedBenefit;
}</content>