import axios from 'axios';
import type { CNPJData } from '../types/cnpj';

interface BrasilAPICNPJResponse {
  cnpj: string;
  razao_social: string;
  cnae_fiscal: string;
  cnae_fiscal_descricao: string;
  municipio: string;
}

const api = axios.create({
  baseURL: 'https://brasilapi.com.br/api',
  timeout: 10000,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  }
});

export const fetchCNPJData = async (cnpj: string): Promise<CNPJData> => {
  try {
    const cleanCNPJ = cnpj.replace(/\D/g, '');
    
    if (cleanCNPJ.length !== 14) {
      throw new Error('CNPJ deve conter 14 dígitos');
    }

    const response = await api.get<BrasilAPICNPJResponse>(`/cnpj/v1/${cleanCNPJ}`);

    if (!response.data) {
      throw new Error('Dados do CNPJ não encontrados');
    }

    return {
      cnpj: response.data.cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5'),
      razaoSocial: response.data.razao_social,
      atividadePrincipal: `${response.data.cnae_fiscal} - ${response.data.cnae_fiscal_descricao}`,
      municipio: response.data.municipio || 'Não informado'
    };
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (!error.response) {
        throw new Error('Erro de conexão. Verifique sua internet e tente novamente.');
      }
      
      switch (error.response.status) {
        case 400:
          throw new Error('CNPJ inválido');
        case 404:
          throw new Error('CNPJ não encontrado na base de dados');
        case 429:
          throw new Error('Limite de consultas excedido. Tente novamente em alguns minutos.');
        case 500:
          throw new Error('Erro no servidor da Receita Federal. Tente novamente mais tarde.');
        default:
          throw new Error(`Erro ${error.response.status}: ${error.response.data?.message || 'Erro desconhecido'}`);
      }
    }
    throw new Error('Erro inesperado ao consultar CNPJ. Tente novamente.');
  }
};