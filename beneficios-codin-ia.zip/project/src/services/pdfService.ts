import { getDocument, GlobalWorkerOptions, version } from 'pdfjs-dist';
import { CNPJData } from '../types/cnpj';

const workerSrc = `https://unpkg.com/pdfjs-dist@${version}/build/pdf.worker.min.js`;
GlobalWorkerOptions.workerSrc = workerSrc;

interface ProgressCallback {
  (progress: number, status: string): void;
}

const cleanText = (text: string): string => {
  return text
    .replace(/\s+/g, ' ')
    .replace(/\n+/g, '\n')
    .trim();
};

const validateCNPJData = (data: Partial<CNPJData>): data is CNPJData => {
  if (!data.cnpj || !data.razaoSocial || !data.atividadePrincipal) {
    const missing = [];
    if (!data.cnpj) missing.push('CNPJ');
    if (!data.razaoSocial) missing.push('Razão Social');
    if (!data.atividadePrincipal) missing.push('Atividade Principal');
    throw new Error(`Dados obrigatórios não encontrados: ${missing.join(', ')}`);
  }
  return true;
};

const formatCNPJ = (cnpj: string): string => {
  const numbers = cnpj.replace(/[^\d]/g, '');
  if (numbers.length !== 14) {
    throw new Error('CNPJ inválido: deve conter 14 dígitos');
  }
  return numbers.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
};

export const extractCNPJData = async (text: string): Promise<CNPJData> => {
  try {
    const normalizedText = cleanText(text);

    // More specific patterns to match CNPJ card format
    const patterns = {
      cnpj: /(?:CNPJ|NÚMERO DE INSCRIÇÃO)[:\s]*(\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2})/i,
      razaoSocial: /(?:NOME\s*EMPRESARIAL|RAZÃO\s*SOCIAL)[:\s]*([^\n]+)/i,
      atividadePrincipal: /(?:CÓDIGO\s*E\s*DESCRIÇÃO\s*DA\s*ATIVIDADE\s*ECONÔMICA\s*PRINCIPAL|ATIVIDADE\s*ECONÔMICA\s*PRINCIPAL)[:\s]*(?:\d{2}\.\d{2}-\d-\d{2}\s*-\s*)?([^\n]+)/i
    };

    const extractField = (pattern: RegExp, fieldName: string): string => {
      const match = pattern.exec(normalizedText);
      if (!match?.[1]?.trim()) {
        throw new Error(`Campo não encontrado: ${fieldName}`);
      }
      return match[1].trim();
    };

    const data: Partial<CNPJData> = {
      cnpj: extractField(patterns.cnpj, 'CNPJ'),
      razaoSocial: extractField(patterns.razaoSocial, 'Razão Social'),
      atividadePrincipal: extractField(patterns.atividadePrincipal, 'Atividade Principal')
    };

    if (validateCNPJData(data)) {
      return {
        cnpj: formatCNPJ(data.cnpj),
        razaoSocial: data.razaoSocial,
        atividadePrincipal: data.atividadePrincipal.replace(/^\d+\s*-\s*/, '')
      };
    }

    throw new Error('Falha na validação dos dados do CNPJ');
  } catch (error) {
    console.error('Erro ao extrair dados do texto:', error);
    throw error instanceof Error 
      ? error 
      : new Error('Não foi possível extrair os dados do cartão CNPJ');
  }
};

export const extractTextFromPDF = async (
  file: File,
  onProgress?: ProgressCallback
): Promise<CNPJData> => {
  try {
    onProgress?.(0, 'Validando arquivo...');
    
    if (!file || !(file instanceof File)) {
      throw new Error('Arquivo inválido');
    }

    if (file.type !== 'application/pdf') {
      throw new Error('O arquivo deve estar no formato PDF');
    }

    if (file.size === 0) {
      throw new Error('O arquivo está vazio');
    }

    if (file.size > 5 * 1024 * 1024) {
      throw new Error('O arquivo é muito grande (máximo 5MB)');
    }

    onProgress?.(10, 'Carregando PDF...');
    const arrayBuffer = await file.arrayBuffer();

    const loadingTask = getDocument({
      data: new Uint8Array(arrayBuffer),
      useWorkerFetch: true,
      isEvalSupported: true,
      useSystemFonts: true
    });
    
    loadingTask.onProgress = ({ loaded, total }) => {
      const progress = total ? Math.round((loaded / total) * 40) + 10 : 10;
      onProgress?.(progress, 'Processando PDF...');
    };
    
    const pdf = await loadingTask.promise;
    
    if (pdf.numPages === 0) {
      throw new Error('O PDF não contém páginas');
    }

    let fullText = '';
    const totalPages = pdf.numPages;
    
    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      try {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent({
          normalizeWhitespace: true,
          disableCombineTextItems: false
        });
        
        if (!textContent?.items?.length) {
          console.warn(`Página ${pageNum} sem texto extraível`);
          continue;
        }

        // Group text items by their vertical position
        const textItems = textContent.items as { str: string; transform: number[] }[];
        const lineHeight = 12;
        const lines: { [key: number]: string[] } = {};

        textItems.forEach(item => {
          if (!item.str.trim()) return;
          const y = Math.round(item.transform[5] / lineHeight) * lineHeight;
          lines[y] = lines[y] || [];
          lines[y].push(item.str);
        });

        // Combine lines maintaining layout
        const sortedYPositions = Object.keys(lines)
          .map(Number)
          .sort((a, b) => b - a);

        sortedYPositions.forEach(y => {
          const lineText = lines[y].join(' ').trim();
          if (lineText) {
            fullText += lineText + '\n';
          }
        });
        
        const progress = Math.round((pageNum / totalPages) * 40) + 50;
        onProgress?.(progress, `Processando página ${pageNum} de ${totalPages}...`);
      } catch (pageError) {
        console.error(`Erro na página ${pageNum}:`, pageError);
        throw new Error(`Erro ao processar a página ${pageNum} do PDF`);
      }
    }

    if (!fullText.trim()) {
      throw new Error('Não foi possível extrair texto do PDF. O arquivo pode estar protegido ou conter apenas imagens.');
    }

    onProgress?.(90, 'Extraindo dados do CNPJ...');
    const cnpjData = await extractCNPJData(fullText);
    
    onProgress?.(100, 'Processamento concluído');
    return cnpjData;

  } catch (error) {
    console.error('Erro ao extrair texto do PDF:', error);
    throw error instanceof Error 
      ? error 
      : new Error('Falha ao processar o PDF');
  }
};