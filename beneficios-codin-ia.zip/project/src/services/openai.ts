import OpenAI from 'openai';
import type { CNPJData } from '../types/cnpj';
import { parseTaxBenefits, getCurrentBenefits, getBenefitsByActivity } from './taxBenefitsParser';

const FUNDES_KNOWLEDGE = `
Análise da Carta Consulta FUNDES
Este documento detalha os principais temas e informações presentes na "Carta Consulta FUNDES", um formulário para solicitação de apoio financeiro junto ao Fundo de Desenvolvimento Econômico e Social do Estado do Rio de Janeiro.

Objetivo: A carta consulta serve para que empresas (ou grupos econômicos) apresentem projetos de investimento à CODIN (Companhia de Desenvolvimento Industrial do Estado do Rio de Janeiro) visando obter apoio financeiro através do FUNDES. Os projetos podem ser de implantação, expansão, relocalização, modernização, entre outros.

Informações Requeridas: O formulário é extenso e busca coletar informações detalhadas sobre a empresa e o projeto em questão. As principais seções e informações solicitadas são:

I. EMPRESA:

Dados cadastrais: Razão Social, CNPJ, endereço, contatos, website, data de constituição, número de empregados.
Estrutura societária: Controle de capital (acionistas e participação), composição da diretoria e conselho de administração.
Histórico da empresa: Resumo dos principais fatos desde a fundação, destacando o número de empregados.
Setores de atuação e principais produtos.
Descrição das unidades industriais e localização.
Tecnologia utilizada (própria ou adquirida).
Informações sobre a produção:
Capacidade instalada e produção efetiva do último ano, por produto.
Demonstrativo dos últimos 3 anos com: Faturamento, número de empregados e recolhimento de ICMS.
II. PROJETO:

Descrição sumária do objetivo do projeto: Detalhando o tipo de projeto (implantação, expansão, etc.), localização e principais fatores que justificam a escolha do local (em casos de implantação ou relocalização).
Metas a serem alcançadas e atendimento às exigências ambientais.
Dados da produção futura: Capacidade e produção estimada por produto.
Quadro de Usos e Fontes: Detalhando os investimentos realizados e a realizar no projeto, com discriminação por trimestre, e as fontes de recursos (próprios e de terceiros).
Quadro Resumo de Usos e Fontes: Consolidando as informações do quadro anterior em valores totais (R$ 1.000,00).
Projeções dos Resultados Incrementais: Estimativas para os próximos 5 anos, incluindo: Faturamento, número de empregados, débitos e créditos de ICMS, e ICMS a recolher.
Outras observações: Convênios com instituições de pesquisa, programa de desenvolvimento de fornecedores, data de início ou aumento da produção.
III. MERCADO:

Descrição do mercado e participação da empresa: Por linha de produto, na situação atual e após a realização do projeto.
Principais concorrentes e suas participações no mercado.
Sistemas de comercialização e canais de distribuição.
Relação dos principais clientes e fornecedores: Nome, estado, país e percentual de participação.
Documentos Complementares:

Além do preenchimento da carta consulta, a empresa deve anexar diversos documentos comprobatórios, como: Contrato Social, demonstrações financeiras, certidão negativa de ICMS, referências bancárias, autorização para análise pela Agência de Fomento do Estado do Rio de Janeiro, currículo dos sócios (se empresa recém-constituída), estudo de avaliação de mercado, projeto de viabilidade, cronograma físico do projeto e licença ambiental.

Taxas e Análise:

A Agência de Fomento do Estado do Rio de Janeiro, agente financeiro do FUNDES, cobra uma tarifa para análise do projeto, equivalente a 0,02% do valor do financiamento proposto, com limites mínimo e máximo estabelecidos.
A empresa também precisa oferecer garantias, apresentar licença de operação emitida pela FEEMA e atender às demais condições do contrato de financiamento.
Declaração de Veracidade:

A empresa declara, sob penas da lei, que as informações prestadas na carta consulta e nos documentos anexos são verdadeiras e corretas.

Observações:

A carta consulta deve ser preenchida em modelo próprio, rubricada em todas as folhas e encaminhada à CODIN em uma via, juntamente com duas vias dos anexos.
É fundamental preencher o formulário da maneira mais completa possível, a fim de facilitar a avaliação do projeto.
A CODIN se coloca à disposição para esclarecimento de dúvidas.
Em suma, a "Carta Consulta FUNDES" é um documento crucial para empresas que buscam apoio financeiro para seus projetos de investimento no Estado do Rio de Janeiro. O detalhamento das informações solicitadas demonstra a importância da análise criteriosa da viabilidade do projeto por parte da CODIN.

Nova nota
FUNDES – CARTA CONSULTA: Perguntas Frequentes
1. O que é o FUNDES e qual o seu objetivo?
O Fundo de Desenvolvimento Econômico e Social (FUNDES) é um programa governamental do Estado do Rio de Janeiro que visa apoiar financeiramente projetos de investimento que contribuam para o desenvolvimento econômico e social do estado. O objetivo é fomentar a geração de empregos, aumentar a arrecadação de impostos e promover o desenvolvimento de diversos setores da economia.

2. Quem pode solicitar apoio financeiro do FUNDES?
Empresas de diversos setores da economia podem solicitar apoio do FUNDES, desde que estejam localizadas no Estado do Rio de Janeiro e apresentem um projeto de investimento que se enquadre nas diretrizes do programa. Os projetos podem ser de implantação, expansão, relocalização, modernização, melhoria de qualidade e produtividade, capacitação tecnológica, conservação do meio ambiente, entre outros.

3. Quais os tipos de projetos que podem ser financiados pelo FUNDES?
O FUNDES pode financiar diversos tipos de projetos, incluindo:

Implantação: Criação de uma nova unidade produtiva.
Expansão: Aumento da capacidade produtiva de uma unidade já existente.
Relocalização: Transferência de uma unidade produtiva para outro local.
Modernização: Aquisição de novas tecnologias e equipamentos para melhorar a eficiência da produção.
Melhoria de qualidade e produtividade: Implementação de sistemas de gestão da qualidade e programas de treinamento para aumentar a produtividade.
Capacitação tecnológica: Investimento em pesquisa e desenvolvimento de novas tecnologias.
Conservação do meio ambiente: Implementação de medidas para reduzir o impacto ambiental da empresa.
4. Como solicitar o apoio financeiro do FUNDES?
A solicitação de apoio financeiro do FUNDES é feita através da Carta Consulta, um documento que deve ser preenchido com informações detalhadas sobre a empresa e o projeto de investimento. A Carta Consulta, juntamente com os documentos complementares, deve ser enviada à Companhia de Desenvolvimento Industrial do Estado do Rio de Janeiro (CODIN).

5. Quais documentos devem ser anexados à Carta Consulta?
Além da Carta Consulta preenchida, é necessário anexar os seguintes documentos:

Cópia do Contrato Social ou Estatuto da empresa, com as respectivas alterações e ata de eleição da atual diretoria.
Três últimos demonstrativos financeiros anteriores à entrada da Carta-Consulta, bem como do último balancete.
Certidão Negativa de ICMS, com validade de 6 (seis) meses a partir da expedição.
Referências bancárias.
Autorização, conforme modelo anexo à Carta Consulta.
Se a empresa compor grupo econômico, também encaminhar os documentos acima relacionados relativos ao grupo ou às suas principais empresas.
Tratando-se de empresa recém constituída, além dos documentos acima, encaminhar curriculum dos sócios e administradores.
Cópia (caso exista) de estudo de avaliação de mercado encomendado pela empresa e cópia (caso exista) de projeto de viabilidade.
Cronograma físico mensal detalhando as fases de implantação do projeto.
Cópia da licença ambiental de acordo com o estágio do projeto objeto desta Carta-Consulta.
6. Quais as taxas e custos envolvidos na solicitação de apoio financeiro do FUNDES?
Após o enquadramento do projeto, a Agência de Fomento do Estado do Rio de Janeiro, na qualidade de Agente Financeiro do FUNDES, cobrará da empresa uma tarifa correspondente a 0,02% do valor do financiamento proposto pela CODIN, com limite mínimo de R$ 3.000,00 e limite máximo de R$ 24.000,00.

7. Quais garantias a empresa precisa oferecer para obter o financiamento do FUNDES?
A empresa postulante deverá oferecer garantias que serão analisadas pela Agência de Fomento do Estado do Rio de Janeiro, além de apresentar a licença de operação emitida pela FEEMA e atender às demais condições do Contrato de Financiamento. As garantias podem variar de acordo com o projeto e o perfil da empresa.

8. Onde posso obter mais informações sobre o FUNDES?
A CODIN se coloca à disposição dos interessados para os esclarecimentos que se fizerem necessários:

Endereço: Av. Rio Branco, nº 110 – 19º andar / 34° andar – Centro 20040 -001 Rio de Janeiro
Telefone: (21) 2334 1400
Fax: (21) 2334 1416
`;

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export const analyzeTaxBenefits = async (
  cnpjData: CNPJData,
  answers: Record<string, string | boolean>
): Promise<string> => {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-2024-08-06",
      messages: [
        {
          role: "system",
          content: `Você é um especialista em benefícios fiscais do estado do Rio de Janeiro.
          
          Analise os dados da empresa e os benefícios fiscais disponíveis para gerar um relatório detalhado.
          
          Regras para o relatório:
          1. Use formatação Markdown
          2. Seja objetivo e direto
          3. Considere o faturamento da empresa ao recomendar benefícios
          4. Explique os requisitos e procedimentos para cada benefício
          5. Cite as bases legais relevantes
          6. Se não houver benefícios específicos, sugira alternativas gerais`
        },
        {
          role: "user",
          content: JSON.stringify({
            empresa: cnpjData,
            respostas: answers
          })
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    return completion.choices[0].message.content || 'Não foi possível gerar a análise.';
  } catch (error) {
    console.error('Erro ao analisar benefícios fiscais:', error);
    throw new Error('Falha ao analisar os benefícios fiscais. Por favor, tente novamente.');
  }
};

export const getCodinResponse = async (
  messages: Array<{ role: 'user' | 'assistant'; content: string }>,
  cnpjData: CNPJData
) => {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `Você é um especialista em benefícios fiscais do estado do Rio de Janeiro e no programa FUNDES.
          Use estas informações como base de conhecimento para suas respostas:
          
          ${FUNDES_KNOWLEDGE}
          
          Regras para suas respostas:
          1. Seja direto e objetivo
          2. Use linguagem profissional mas acessível
          3. Formate as respostas em Markdown quando necessário
          4. Cite as fontes legais quando relevante
          5. Considere os dados da empresa ao fornecer orientações específicas
          6. Mantenha o foco em benefícios fiscais do RJ e no FUNDES`
        },
        ...messages
      ],
      stream: true,
      temperature: 0.5,
      max_tokens: 2000
    });

    return completion;
  } catch (error) {
    console.error('Erro ao processar mensagem:', error);
    throw new Error('Falha ao processar sua mensagem. Por favor, tente novamente.');
  }
};