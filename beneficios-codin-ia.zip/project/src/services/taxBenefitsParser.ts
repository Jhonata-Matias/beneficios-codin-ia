import { format, isAfter, parseISO } from 'date-fns';

interface TaxBenefitItem {
  name: string;
  legislation: {
    reference: string;
    url?: string;
  }[];
  type: string[];
  deadline: string;
  details?: string;
  updates?: {
    reference: string;
    url?: string;
    description: string;
  }[];
  foundation?: {
    reference: string;
    url?: string;
  };
  status: 'active' | 'expired';
}

export const parseTaxBenefits = (html: string): TaxBenefitItem[] => {
  const benefits: TaxBenefitItem[] = [];
  const sections = html.split('<p>&nbsp;</p>');
  const currentDate = new Date();

  sections.forEach(section => {
    // Extract benefit name
    const nameMatch = section.match(/<strong>(.*?)<\/strong>/);
    if (!nameMatch) return;

    const name = nameMatch[1].replace(/\.$/, '').trim();
    
    // Extract legislation
    const legislationMatches = section.matchAll(/<a href="([^"]*)"[^>]*>([^<]*)<\/a>/g);
    const legislation = Array.from(legislationMatches)
      .filter(match => !match[2].includes('redação(ões) anterior(es)'))
      .map(match => ({
        reference: match[2].trim().replace(/\.$/, ''),
        url: match[1].startsWith('http') ? match[1] : `https://legislacao.fazenda.rj.gov.br${match[1]}`
      }));

    // Extract benefit types
    const typeMatch = section.match(/<p[^>]*>([^<]*(?:Diferimento|Isenção|Redução[^<]*|Crédito Presumido|Tributação sobre saída))<\/p>/);
    const types = typeMatch 
      ? typeMatch[1].split(';').map(t => t.trim())
      : [];

    // Extract deadline
    const deadlineMatch = section.match(/Prazo[^<]*até ([^<\.]*)/);
    const deadline = deadlineMatch ? deadlineMatch[1].trim() : 'Prazo indeterminado';

    // Extract updates
    const updateMatches = section.match(/<em><span[^>]*>\(([^<]*)\)<\/span><\/em>/g);
    const updates = updateMatches?.map(update => {
      const updateText = update.replace(/<[^>]+>/g, '').replace(/[\(\)]/g, '').trim();
      const updateUrlMatch = update.match(/<a href="([^"]*)"[^>]*>([^<]*)<\/a>/);
      return {
        description: updateText,
        reference: updateUrlMatch ? updateUrlMatch[2].trim() : '',
        url: updateUrlMatch ? `https://legislacao.fazenda.rj.gov.br${updateUrlMatch[1]}` : undefined
      };
    });

    // Extract foundation
    const foundationMatch = section.match(/fundamento no <a href="([^"]*)"[^>]*>([^<]*)<\/a>/);
    const foundation = foundationMatch ? {
      reference: foundationMatch[2].trim(),
      url: foundationMatch[1]
    } : undefined;

    // Extract additional details
    const detailsMatches = section.match(/<p[^>]*>(?!Prazo)([^<]+)<\/p>/g);
    const details = detailsMatches 
      ? detailsMatches
          .map(match => match.replace(/<[^>]+>/g, '').trim())
          .filter(detail => detail && !detail.includes('Prazo'))
          .join('\n')
      : undefined;

    // Determine if benefit is active
    let status: 'active' | 'expired' = 'active';
    if (deadline !== 'Prazo indeterminado') {
      try {
        const deadlineDate = parseISO(deadline.split('/').reverse().join('-'));
        if (isAfter(currentDate, deadlineDate)) {
          status = 'expired';
        }
      } catch (error) {
        console.warn(`Invalid date format for benefit ${name}: ${deadline}`);
      }
    }

    benefits.push({
      name,
      legislation,
      type: types,
      deadline,
      details,
      updates,
      foundation,
      status
    });
  });

  return benefits;
};

export const getCurrentBenefits = (benefits: TaxBenefitItem[]): TaxBenefitItem[] => {
  const currentDate = new Date();
  
  return benefits.filter(benefit => {
    if (benefit.deadline === 'Prazo indeterminado') return true;
    
    try {
      const deadlineDate = parseISO(benefit.deadline.split('/').reverse().join('-'));
      return !isAfter(currentDate, deadlineDate);
    } catch {
      return false;
    }
  });
};

export const getBenefitsByActivity = (
  benefits: TaxBenefitItem[], 
  activity: string
): TaxBenefitItem[] => {
  const normalizedActivity = activity.toLowerCase();
  
  return benefits.filter(benefit => 
    benefit.name.toLowerCase().includes(normalizedActivity) ||
    benefit.details?.toLowerCase().includes(normalizedActivity)
  );
};