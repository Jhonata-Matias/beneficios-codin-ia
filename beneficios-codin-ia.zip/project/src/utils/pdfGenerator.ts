import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

const parseMarkdown = (text: string) => {
  text = text.replace(/^# (.*$)/gm, '$1');
  text = text.replace(/^## (.*$)/gm, '$1');
  text = text.replace(/^### (.*$)/gm, '{{h3}}$1{{/h3}}');
  text = text.replace(/\{\{\/h3\}\}/g, '');
  text = text.replace(/^- (.*$)/gm, '• $1');
  text = text.replace(/\*\*(.*?)\*\*/g, '{{bold}}$1{{/bold}}');
  text = text.replace(/\{\{\/bold\}\}/g, '');
  return text;
};

export const generatePDF = async (analysis: string, cnpjData: any, answers: any) => {
  try {
    const pdfDoc = await PDFDocument.create();
    const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    const pageSize = { width: 595.276, height: 841.890 }; // A4
    const margins = {
      top: 70,
      bottom: 90,
      left: 72,
      right: 72
    };

    const contentWidth = pageSize.width - margins.left - margins.right;
    const lineHeight = 16;
    const footerHeight = 60;

    const addPage = () => {
      const page = pdfDoc.addPage([pageSize.width, pageSize.height]);
      const yPosition = pageSize.height - margins.top;

      const footerY = margins.bottom - 30;

      page.drawText(`Página ${pdfDoc.getPageCount()} de ${pdfDoc.getPageCount()}`, {
        x: pageSize.width - margins.right - 100,
        y: footerY,
        size: 10,
        font: helvetica,
        color: rgb(0.5, 0.5, 0.5)
      });

      page.drawText('Gerado pela Contabhub Tecnologia LTDA', {
        x: margins.left,
        y: footerY,
        size: 10,
        font: helvetica,
        color: rgb(0.5, 0.5, 0.5)
      });

      page.drawLine({
        start: { x: margins.left - 10, y: footerY + 15 },
        end: { x: pageSize.width - margins.right + 10, y: footerY + 15 },
        thickness: 0.5,
        color: rgb(0.8, 0.8, 0.8)
      });

      return { page, yPosition };
    };

    let { page, yPosition } = addPage();

    page.drawRectangle({
      x: margins.left - 10,
      y: yPosition - 10,
      width: contentWidth + 20,
      height: 50,
      color: rgb(0.95, 0.95, 1)
    });

    page.drawText('Relatório de Análise de Benefícios Fiscais - RJ', {
      x: margins.left,
      y: yPosition,
      size: 16,
      font: helveticaBold,
      color: rgb(0.2, 0.2, 0.8)
    });

    yPosition -= 80;

    if (cnpjData?.cnpj && cnpjData?.razaoSocial && cnpjData?.atividadePrincipal) {
      page.drawRectangle({
        x: margins.left - 10,
        y: yPosition - 80,
        width: contentWidth + 20,
        height: 70,
        color: rgb(0.97, 0.97, 0.97)
      });

      const drawText = (text: string, y: number, font = helvetica) => {
        page.drawText(text, {
          x: margins.left,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
      };

      drawText(`CNPJ: ${cnpjData.cnpj}`, yPosition - 20, helveticaBold);
      drawText(`Razão Social: ${cnpjData.razaoSocial}`, yPosition - 40, helveticaBold);
      drawText(`Atividade Principal: ${cnpjData.atividadePrincipal}`, yPosition - 60);

      yPosition -= 120;
    }

    const drawText = (text: string, { y, size = 11, font = helvetica, indent = 0 }) => {
      const effectiveWidth = contentWidth - indent;
      const words = text.split(' ');
      let currentLine = [];
      let currentLineWidth = 0;
      let xPosition = margins.left + indent;
      let currentY = y;
      let currentFont = font;
      let currentSize = size;
      let isBold = false;

      const drawJustifiedLine = (line: { text: string; font: typeof helvetica }[], y: number, isLastLine = false) => {
        if (line.length === 0) return;

        const totalWidth = line.reduce((sum, { text, font }) => 
          sum + font.widthOfTextAtSize(text, currentSize), 0);
        
        const spaceWidth = isLastLine ? font.widthOfTextAtSize(' ', currentSize) 
          : (effectiveWidth - totalWidth) / (line.length - 1);
        
        let currentX = xPosition;
        
        line.forEach(({ text, font }, index) => {
          page.drawText(text, {
            x: currentX,
            y,
            size: currentSize,
            font,
            color: rgb(0, 0, 0)
          });
          
          currentX += font.widthOfTextAtSize(text, currentSize) + 
            (index < line.length - 1 ? spaceWidth : 0);
        });
      };

      for (const word of words) {
        let processedWord = word;
        let wordFont = currentFont;

        if (word.includes('{{bold}}')) {
          processedWord = word.replace('{{bold}}', '');
          wordFont = helveticaBold;
          isBold = true;
        } else if (isBold && !word.includes('{{/bold}}')) {
          wordFont = helveticaBold;
        } else if (word.includes('{{/bold}}')) {
          processedWord = word.replace('{{/bold}}', '');
          wordFont = helvetica;
          isBold = false;
        }

        if (word.includes('{{h3}}')) {
          processedWord = word.replace('{{h3}}', '').replace('{{/h3}}', '');
          wordFont = helveticaBold;
          currentSize = 14;
        }

        const wordWidth = wordFont.widthOfTextAtSize(processedWord, currentSize);
        const spaceWidth = helvetica.widthOfTextAtSize(' ', currentSize);

        if (currentLineWidth + wordWidth > effectiveWidth) {
          drawJustifiedLine(currentLine, currentY);
          currentY -= lineHeight;
          currentLine = [{ text: processedWord, font: wordFont }];
          currentLineWidth = wordWidth;

          if (currentY < margins.bottom + footerHeight) {
            ({ page, yPosition } = addPage());
            currentY = yPosition;
          }
        } else {
          currentLine.push({ text: processedWord, font: wordFont });
          currentLineWidth += wordWidth + spaceWidth;
        }
      }

      if (currentLine.length > 0) {
        drawJustifiedLine(currentLine, currentY, true);
      }

      return currentY;
    };

    const parsedContent = parseMarkdown(analysis);
    const sections = parsedContent.split('\n\n');

    for (const section of sections) {
      if (yPosition < margins.bottom + footerHeight) {
        ({ page, yPosition } = addPage());
      }

      const lines = section.split('\n');
      
      for (const line of lines) {
        if (line.trim()) {
          yPosition = drawText(line, { 
            y: yPosition, 
            indent: line.startsWith('• ') ? 20 : 0 
          });
          yPosition -= lineHeight;
        } else {
          yPosition -= lineHeight / 2;
        }
      }
      
      yPosition -= lineHeight;
    }

    const pageCount = pdfDoc.getPageCount();
    for (let i = 0; i < pageCount; i++) {
      const page = pdfDoc.getPage(i);
      page.drawText(`Página ${i + 1} de ${pageCount}`, {
        x: pageSize.width - margins.right - 100,
        y: margins.bottom - 30,
        size: 10,
        font: helvetica,
        color: rgb(0.5, 0.5, 0.5)
      });
    }

    const pdfBytes = await pdfDoc.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `analise-beneficios-fiscais-${cnpjData?.cnpj || 'sem-cnpj'}.pdf`;
    link.click();
    window.URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Erro ao gerar PDF:', error);
    throw error instanceof Error 
      ? error 
      : new Error('Falha ao gerar o PDF do relatório');
  }
};