import React, { useState, useEffect } from 'react';
import { Building2, Users, MapPin, DollarSign, ClipboardCheck } from 'lucide-react';

const QuestionsForm = ({ cnpjData, onSubmit }) => {
  const [formData, setFormData] = useState({
    revenue: '',
    employees: '',
    location: '',
    hasEnvironmentalLicense: false,
    investmentPlan: false
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  // Set location based on CNPJ data when component mounts or cnpjData changes
  useEffect(() => {
    if (cnpjData?.municipio) {
      const locationMap = {
        'RIO DE JANEIRO': 'rio',
        'NITEROI': 'niteroi',
        'DUQUE DE CAXIAS': 'duque',
        'NOVA IGUACU': 'nova'
      };

      setFormData(prev => ({
        ...prev,
        location: locationMap[cnpjData.municipio.toUpperCase()] || 'outros'
      }));
    }
  }, [cnpjData]);

  return (
    <div className="min-h-[calc(100vh-16rem)] flex flex-col">
      <div className="max-w-3xl mx-auto w-full bg-white rounded-lg p-8">
        <div className="bg-indigo-50 rounded-lg p-6 mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">
            Dados da Empresa
          </h3>
          <div className="space-y-3">
            <p className="text-gray-700">
              <strong>CNPJ:</strong> {cnpjData.cnpj}
            </p>
            <p className="text-gray-700">
              <strong>Razão Social:</strong> {cnpjData.razaoSocial}
            </p>
            <p className="text-gray-700">
              <strong>Atividade Principal:</strong> {cnpjData.atividadePrincipal}
            </p>
            <p className="text-gray-700">
              <strong>Município:</strong> {cnpjData.municipio}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div>
            <label className="flex items-center text-lg font-medium text-gray-700 mb-3">
              <DollarSign className="h-6 w-6 mr-2 text-indigo-600" />
              Faturamento anual aproximado
            </label>
            <select
              value={formData.revenue}
              onChange={(e) => setFormData({ ...formData, revenue: e.target.value })}
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
              required
            >
              <option value="">Selecione uma faixa</option>
              <option value="1">Até R$ 360 mil</option>
              <option value="2">De R$ 360 mil a R$ 4,8 milhões</option>
              <option value="3">De R$ 4,8 milhões a R$ 300 milhões</option>
              <option value="4">Acima de R$ 300 milhões</option>
            </select>
          </div>

          <div>
            <label className="flex items-center text-lg font-medium text-gray-700 mb-3">
              <Users className="h-6 w-6 mr-2 text-indigo-600" />
              Número de funcionários
            </label>
            <input
              type="number"
              value={formData.employees}
              onChange={(e) => setFormData({ ...formData, employees: e.target.value })}
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
              required
              min="0"
            />
          </div>

          <div>
            <label className="flex items-center text-lg font-medium text-gray-700 mb-3">
              <MapPin className="h-6 w-6 mr-2 text-indigo-600" />
              Município de localização
            </label>
            <select
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
              required
            >
              <option value="">Selecione o município</option>
              <option value="rio">Rio de Janeiro</option>
              <option value="niteroi">Niterói</option>
              <option value="duque">Duque de Caxias</option>
              <option value="nova">Nova Iguaçu</option>
              <option value="outros">Outros municípios do RJ</option>
            </select>
          </div>

          <div className="space-y-6 bg-gray-50 p-6 rounded-lg">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="environmental"
                checked={formData.hasEnvironmentalLicense}
                onChange={(e) => setFormData({ ...formData, hasEnvironmentalLicense: e.target.checked })}
                className="h-5 w-5 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
              />
              <label htmlFor="environmental" className="ml-3 text-lg text-gray-700">
                Possui licença ambiental válida
              </label>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="investment"
                checked={formData.investmentPlan}
                onChange={(e) => setFormData({ ...formData, investmentPlan: e.target.checked })}
                className="h-5 w-5 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
              />
              <label htmlFor="investment" className="ml-3 text-lg text-gray-700">
                Possui plano de investimentos para os próximos 5 anos
              </label>
            </div>
          </div>

          <div className="pt-6">
            <button
              type="submit"
              className="w-full flex justify-center items-center px-6 py-4 border border-transparent rounded-lg shadow-sm text-lg font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
            >
              <ClipboardCheck className="h-6 w-6 mr-2" />
              Analisar Benefícios Disponíveis
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default QuestionsForm;