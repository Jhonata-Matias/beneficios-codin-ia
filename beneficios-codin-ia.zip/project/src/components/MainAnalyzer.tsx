import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import FileUploader from './FileUploader';
import QuestionsForm from './QuestionsForm';
import Report from './Report';

function MainAnalyzer() {
  const [step, setStep] = useState(1);
  const [cnpjData, setCnpjData] = useState(null);
  const [answers, setAnswers] = useState({});
  const location = useLocation();
  const navigate = useNavigate();

  // Check if we're returning from the CODIN chat
  React.useEffect(() => {
    if (location.state?.returnToReport) {
      setStep(3);
      setCnpjData(location.state.previousData?.cnpjData);
      setAnswers(location.state.previousData?.answers);
    }
  }, [location]);

  const handleFileUpload = (data) => {
    setCnpjData(data);
    setStep(2);
  };

  const handleQuestionsSubmit = (formData) => {
    setAnswers(formData);
    setStep(3);
  };

  const handleReset = () => {
    // Clear all state
    setStep(1);
    setCnpjData(null);
    setAnswers({});
    
    // Clear location state
    navigate('/analyzer', { replace: true });
  };

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-2xl shadow-xl p-8">
        {/* Progress Steps */}
        <div className="flex justify-center mb-12">
          <div className="flex items-center">
            <div className={`flex items-center justify-center w-10 h-10 rounded-full 
              ${step >= 1 ? 'bg-indigo-600' : 'bg-gray-200'}`}>
              <Upload className={`w-5 h-5 ${step >= 1 ? 'text-white' : 'text-gray-500'}`} />
            </div>
            <div className={`w-24 h-1 ${step >= 2 ? 'bg-indigo-600' : 'bg-gray-200'}`} />
            <div className={`flex items-center justify-center w-10 h-10 rounded-full 
              ${step >= 2 ? 'bg-indigo-600' : 'bg-gray-200'}`}>
              <FileText className={`w-5 h-5 ${step >= 2 ? 'text-white' : 'text-gray-500'}`} />
            </div>
            <div className={`w-24 h-1 ${step >= 3 ? 'bg-indigo-600' : 'bg-gray-200'}`} />
            <div className={`flex items-center justify-center w-10 h-10 rounded-full 
              ${step >= 3 ? 'bg-indigo-600' : 'bg-gray-200'}`}>
              <CheckCircle className={`w-5 h-5 ${step >= 3 ? 'text-white' : 'text-gray-500'}`} />
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-3xl mx-auto">
          {step === 1 && (
            <>
              <FileUploader onFileUpload={handleFileUpload} />
              <div className="mt-6 bg-blue-50 border border-blue-100 rounded-lg p-4">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-blue-400" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-blue-700">
                      Este sistema analisa exclusivamente benefícios fiscais do estado do Rio de Janeiro.
                      Por favor, certifique-se de enviar apenas o cartão CNPJ em formato PDF.
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}
          
          {step === 2 && (
            <QuestionsForm 
              cnpjData={cnpjData}
              onSubmit={handleQuestionsSubmit}
            />
          )}
          
          {step === 3 && (
            <Report 
              cnpjData={cnpjData}
              answers={answers}
              onReset={handleReset}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default MainAnalyzer;