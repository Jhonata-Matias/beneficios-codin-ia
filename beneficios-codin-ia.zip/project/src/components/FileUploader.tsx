import React, { useState, useRef } from 'react';
import { Upload, AlertCircle, Search } from 'lucide-react';
import { extractTextFromPDF } from '../services/pdfService';
import { fetchCNPJData } from '../services/cnpjService';
import type { CNPJData } from '../types/cnpj';

interface FileUploaderProps {
  onFileUpload: (data: CNPJData) => void;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ onFileUpload }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<string>('');
  const [cnpj, setCNPJ] = useState('');
  const [apiError, setApiError] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatCNPJ = (value: string) => {
    return value
      .replace(/\D/g, '')
      .replace(/(\d{2})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1/$2')
      .replace(/(\d{4})(\d)/, '$1-$2')
      .slice(0, 18);
  };

  const handleProgress = (progress: number, status: string) => {
    setProgress(progress);
    setStatus(status);
  };

  const handleCNPJChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCNPJ(e.target.value);
    setCNPJ(formatted);
    setError(null);
    setApiError(false);
  };

  const handleCNPJSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    setStatus('Consultando CNPJ...');

    try {
      const cleanCNPJ = cnpj.replace(/\D/g, '');
      if (cleanCNPJ.length !== 14) {
        throw new Error('CNPJ inválido');
      }

      const data = await fetchCNPJData(cleanCNPJ);
      onFileUpload(data);
    } catch (err) {
      setApiError(true);
      setError('API indisponível. Por favor, utilize o upload do PDF do cartão CNPJ.');
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      setLoading(true);
      setError(null);
      setProgress(0);
      setStatus('');

      const cnpjData = await extractTextFromPDF(file, handleProgress);
      onFileUpload(cnpjData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao processar o arquivo.');
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = async (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();

    const file = event.dataTransfer.files?.[0];
    if (!file) return;

    try {
      setLoading(true);
      setError(null);
      setProgress(0);
      setStatus('');

      const cnpjData = await extractTextFromPDF(file, handleProgress);
      onFileUpload(cnpjData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao processar o arquivo.');
    } finally {
      setLoading(false);
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Consulta por CNPJ
        </h3>
        <form onSubmit={handleCNPJSubmit} className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={cnpj}
              onChange={handleCNPJChange}
              placeholder="00.000.000/0000-00"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              maxLength={18}
              disabled={loading}
            />
          </div>
          <button
            type="submit"
            disabled={loading || cnpj.replace(/\D/g, '').length !== 14 || apiError}
            className="w-full flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                {status}
              </>
            ) : (
              <>
                <Search className="w-4 h-4 mr-2" />
                Consultar CNPJ
              </>
            )}
          </button>
        </form>
      </div>

      {(error || apiError) && (
        <div className="text-center">
          <span className="px-4 text-sm text-gray-500">ou</span>
        </div>
      )}

      <div
        onClick={handleClick}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        className={`border-2 border-dashed rounded-lg p-6 cursor-pointer transition-colors 
          ${loading ? 'bg-gray-100' : 'hover:bg-gray-50'} 
          ${error ? 'border-red-300' : 'border-gray-300'}`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="application/pdf"
          onChange={handleFileChange}
          className="hidden"
          disabled={loading}
        />
        
        <div className="flex flex-col items-center justify-center space-y-2">
          <Upload className={`w-8 h-8 ${error ? 'text-red-500' : 'text-gray-400'}`} />
          <p className="text-sm text-center text-gray-600">
            {loading ? 'Processando...' : 'Arraste e solte o cartão CNPJ em PDF ou clique para selecionar'}
          </p>
          <p className="text-xs text-gray-500">
            Apenas arquivos PDF são aceitos
          </p>
        </div>
      </div>

      {loading && progress > 0 && (
        <div className="mt-4 space-y-2">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-sm text-gray-600 text-center">{status}</p>
        </div>
      )}

      {error && (
        <div className="mt-4 p-3 bg-red-50 rounded-lg flex items-start space-x-2">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}
    </div>
  );
};

export default FileUploader;