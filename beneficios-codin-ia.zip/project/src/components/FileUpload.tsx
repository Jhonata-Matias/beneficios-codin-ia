import React, { useCallback } from 'react';
import { FileText } from 'lucide-react';
import { extractTextFromPDF } from '../utils/pdfParser';

interface FileUploadProps {
  onFileProcess: (data: any) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileProcess }) => {
  const handleFileChange = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await extractTextFromPDF(file);
      // Process the extracted text to get CNPJ data
      const cnpjData = {
        cnpj: text.match(/CNPJ:\s*(\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2})/)?.[1] || '',
        razaoSocial: text.match(/NOME EMPRESARIAL:\s*(.*?)(?=\n)/)?.[1] || '',
        atividadePrincipal: text.match(/CÓDIGO E DESCRIÇÃO DA ATIVIDADE ECONÔMICA PRINCIPAL:\s*(.*?)(?=\n)/)?.[1] || ''
      };
      onFileProcess(cnpjData);
    } catch (error) {
      console.error('Erro ao processar PDF:', error);
      // Handle error appropriately in the UI
    }
  }, [onFileProcess]);

  return (
    <div className="flex flex-col items-center justify-center w-full">
      <label className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
        <div className="flex flex-col items-center justify-center pt-5 pb-6">
          <FileText className="w-10 h-10 mb-3 text-gray-400" />
          <p className="mb-2 text-sm text-gray-500">
            <span className="font-semibold">Clique para fazer upload</span> ou arraste e solte
          </p>
          <p className="text-xs text-gray-500">PDF do cartão CNPJ</p>
        </div>
        <input
          type="file"
          className="hidden"
          accept=".pdf"
          onChange={handleFileChange}
        />
      </label>
    </div>
  );
};

export default FileUpload;