import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Send, ArrowLeft } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { getCodinResponse } from '../services/openai';
import type { CNPJData } from '../types/cnpj';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const CodinChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, streamingMessage]);

  useEffect(() => {
    // Add initial welcome message
    if (messages.length === 0) {
      setMessages([{
        role: 'assistant',
        content: `Olá! Sou o assistente especializado em benefícios fiscais do RJ e no programa FUNDES.

Como posso ajudar você hoje?

Posso auxiliar com:
- Informações sobre o FUNDES
- Orientações sobre a Carta Consulta
- Documentação necessária
- Requisitos e elegibilidade
- Custos e taxas envolvidos`
      }]);
    }
  }, []);

  const handleBack = () => {
    navigate('/analyzer', { 
      state: { 
        returnToReport: true,
        previousData: location.state
      } 
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setInput('');
    setIsLoading(true);
    setStreamingMessage('');

    try {
      const stream = await getCodinResponse(
        [...messages, { role: 'user', content: userMessage }],
        location.state?.cnpjData as CNPJData
      );

      let fullResponse = '';
      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || '';
        fullResponse += content;
        setStreamingMessage(prev => prev + content);
      }

      setMessages(prev => [...prev, { role: 'assistant', content: fullResponse }]);
      setStreamingMessage('');
    } catch (error) {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: error instanceof Error 
          ? error.message 
          : 'Desculpe, ocorreu um erro ao processar sua mensagem. Por favor, tente novamente.'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 h-[90vh] w-[80vw] m-auto flex flex-col">
      {/* Header */}
      <div className="flex items-center mb-6">
        <button
          onClick={handleBack}
          className="flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Voltar ao Relatório
        </button>
        <h2 className="text-xl font-semibold text-center flex-1 mr-7">
          Consulta ao CODIN
        </h2>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto mb-6 space-y-4">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-4 ${
                message.role === 'user'
                  ? 'bg-indigo-100 text-gray-900'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <ReactMarkdown className="prose prose-sm max-w-none">
                {message.content}
              </ReactMarkdown>
            </div>
          </div>
        ))}
        {streamingMessage && (
          <div className="flex justify-start">
            <div className="max-w-[80%] rounded-lg p-4 bg-gray-100 text-gray-900">
              <ReactMarkdown className="prose prose-sm max-w-none">
                {streamingMessage}
              </ReactMarkdown>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Digite sua mensagem..."
          className="flex-1 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading}
          className="bg-indigo-600 text-white p-2 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-400 transition-colors"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
};

export default CodinChat;