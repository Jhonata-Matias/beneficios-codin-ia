import React, { useState, useEffect } from 'react';
import { Download, FileText, Send, AlertCircle, RefreshCw } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useNavigate, useLocation } from 'react-router-dom';
import { analyzeTaxBenefits } from '../services/openai';
import { generatePDF } from '../utils/pdfGenerator';
import type { CNPJData } from '../types/cnpj';

interface ReportProps {
  cnpjData: CNPJData;
  answers: Record<string, string | boolean>;
  onReset: () => void;
}

const Report: React.FC<ReportProps> = ({ cnpjData, answers, onReset }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const generateAnalysis = async () => {
      try {
        setLoading(true);
        setError(null);
        const result = await analyzeTaxBenefits(cnpjData, answers);
        setAnalysis(result);
      } catch (err) {
        setError(
          err instanceof Error 
            ? err.message 
            : 'Erro ao gerar análise. Por favor, tente novamente.'
        );
        console.error('Error:', err);
      } finally {
        setLoading(false);
      }
    };

    // Only generate new analysis if not returning from CODIN chat
    if (!location.state?.returnToReport) {
      generateAnalysis();
    } else {
      setLoading(false);
      setAnalysis(location.state.previousData?.analysis);
    }
  }, [cnpjData, answers, location.state]);

  const handleDownloadPDF = async () => {
    if (!analysis) return;

    try {
      await generatePDF(analysis, cnpjData, answers);
    } catch (err) {
      setError(
        err instanceof Error 
          ? err.message 
          : 'Erro ao gerar PDF. Por favor, tente novamente.'
      );
      console.error('Erro ao gerar PDF:', err);
    }
  };

  const handleCodinRequest = () => {
    navigate('/codin-chat', { 
      state: { 
        cnpjData,
        answers,
        analysis 
      } 
    });
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
        <p className="text-gray-600">Analisando benefícios fiscais...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
          <div className="flex items-center gap-2 text-red-600 mb-4">
            <AlertCircle className="h-5 w-5 flex-shrink-0" />
            <span className="font-medium">{error}</span>
          </div>
          <button
            onClick={onReset}
            className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
          >
            <RefreshCw className="h-5 w-5" />
            Tentar Novamente
          </button>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <div className="flex items-center gap-2 text-yellow-600">
            <AlertCircle className="h-5 w-5" />
            <span>Nenhuma análise disponível. Por favor, tente novamente.</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between gap-4 mb-6">
        <button
          onClick={onReset}
          className="flex items-center gap-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
        >
          <RefreshCw className="h-5 w-5" />
          Analisar outra empresa
        </button>
        <div className="flex gap-4">
          <button
            onClick={handleDownloadPDF}
            className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            <Download className="h-5 w-5" />
            Baixar Relatório Completo
          </button>
          <button
            onClick={handleCodinRequest}
            className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            <FileText className="h-5 w-5" />
            Solicitar ao CODIN
          </button>
        </div>
      </div>

      <div className="prose max-w-none bg-white rounded-lg shadow-sm p-8">
        <ReactMarkdown>{analysis}</ReactMarkdown>
      </div>
    </div>
  );
};

export default Report;