import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Info } from 'lucide-react';
import Login from './components/Login';
import Register from './components/Register';
import MainAnalyzer from './components/MainAnalyzer';
import CodinChat from './components/CodinChat';
import AdminDashboard from './components/AdminDashboard';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/admin"
          element={
            <ProtectedRoute requireAdmin>
              <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex flex-col">
                <nav className="bg-white shadow-lg">
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16 items-center">
                      <div className="flex items-center">
                        <Info className="h-8 w-8 text-indigo-600" />
                        <span className="ml-2 text-xl font-semibold text-gray-900">
                          Painel Administrativo
                        </span>
                      </div>
                      <div className="flex items-center space-x-4">
                        <button
                          onClick={() => window.location.href = '/analyzer'}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          Sistema
                        </button>
                        <button
                          onClick={() => {
                            localStorage.removeItem('isAuthenticated');
                            localStorage.removeItem('userRole');
                            window.location.href = '/';
                          }}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          Sair
                        </button>
                      </div>
                    </div>
                  </div>
                </nav>
                <AdminDashboard />
              </div>
            </ProtectedRoute>
          }
        />
        <Route
          path="/analyzer"
          element={
            <ProtectedRoute>
              <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex flex-col">
                <nav className="bg-white shadow-lg">
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16 items-center">
                      <div className="flex items-center">
                        <Info className="h-8 w-8 text-indigo-600" />
                        <span className="ml-2 text-xl font-semibold text-gray-900">
                          RJ Tax Benefits Analyzer
                        </span>
                      </div>
                      <div className="flex items-center space-x-4">
                        {localStorage.getItem('userRole') === 'admin' && (
                          <button
                            onClick={() => window.location.href = '/admin'}
                            className="text-gray-600 hover:text-gray-900"
                          >
                            Admin
                          </button>
                        )}
                        <button
                          onClick={() => {
                            localStorage.removeItem('isAuthenticated');
                            localStorage.removeItem('userRole');
                            window.location.href = '/';
                          }}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          Sair
                        </button>
                      </div>
                    </div>
                  </div>
                </nav>
                <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                  <MainAnalyzer />
                </main>
              </div>
            </ProtectedRoute>
          }
        />
        <Route
          path="/codin-chat"
          element={
            <ProtectedRoute>
              <CodinChat />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;