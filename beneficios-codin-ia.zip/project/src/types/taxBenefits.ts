export interface TaxBenefit {
  name: string;
  legislation: {
    reference: string;
    url?: string;
  };
  type: string[];
  deadline: string;
  details?: string;
  status: 'active' | 'expired';
  lastUpdate?: string;
}

export type BenefitType = 
  | 'Diferimento'
  | 'Isenção'
  | 'Redução de Base de Cálculo'
  | 'Crédito Presumido'
  | 'Redução de Alíquota'
  | 'Tributação sobre saída';