export interface CNPJData {
  cnpj: string;
  razaoSocial: string;
  atividadePrincipal: string;
  municipio: string;
}